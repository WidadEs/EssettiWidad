#include<iostream>
using namespace std;
class complexe{
    public:
    int img1;
    int rel1;
    int img2;
    int rel2;
    
complexe(){}
void donner1(){
    cout<<"veuiller donner la partie reel du nombre complexe 1"<<endl;
    cin>>rel1;
    cout<<"veuiller donner la partie imaginaire du nombre complexe 1"<<endl;
    cin>>img1;
    cout<<"le nombre complexe 1 est"<<rel1<<"+i"<<img1<<endl;
}

void donner2(){
    cout<<"veuiller donner la partie reel du nombre complexe 2"<<endl;
    cin>>rel2;
    cout<<"veuiller donner la partie imaginaire du nombre complexe 2"<<endl;
    cin>>img2;
    cout<<"le nombre complexe 2 est"<<rel2<<"+i"<<img2<<endl;
}

void operator+(complexe){
    img1 +=img2;
    rel1 +=rel2;
    cout<<"la sommation egale a : "<<rel1<<"+i"<<img1<<endl;
}
void operator-(complexe){
    img1-=img2;
    rel1-=rel2;
    cout<<"la soustraction egale a : "<<rel1<<"+i"<<img1<<endl;
}
void operator*(complexe){
    img1=img1*img2;
    rel1=rel1*img2;
    cout<<"le produit egale a : "<<rel1<<"+i"<<img1<<endl;
}
void operator/(complexe){
    img1=img1/img2;
    rel1=rel1/rel2;
    cout<<"la division egale a : "<<rel1<<"+i"<<img1<<endl;
} 
};
int main(){
 complexe c1;
 complexe c2;
 c1.donner1();
 c2.donner2();
 c1+c2;
 c1*c2;
 c1-c2;
 c1/c2;
 return 0;

}